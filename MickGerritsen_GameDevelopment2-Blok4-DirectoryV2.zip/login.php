<?php
    define("DB_SERVER", "localhost");
    define("DB_USER", "mickgerritsen");
    define("DB_PASSWORD", "bohghooP2l");
    define("DB_DATABASE", "mickgerritsen");

    $con = mysqli_connect(DB_SERVER , DB_USER, DB_PASSWORD, DB_DATABASE);
    
    //check connection
    if (mysqli_connect_errno()){
        echo "1: Connection failed"; //failed
        exit();
    }

    $username = $_POST["username"];
    $password = $_POST["password"];

        //check if name exists
    $namecheckquery = "SELECT username, salt, hash, amountofwins, amountoflosses FROM users WHERE username='". $username . "';";
    
    $namecheck = mysqli_query($con, $namecheckquery) or die("2: Name check query failed"); //namecheck query failed
    if (mysqli_num_rows($namecheck) != 1){
        echo "5: Either no user with name or more than one"; //wrong matching username
        exit();
    }

    //get login info from query
    $existinginfo = mysqli_fetch_assoc($namecheck);
    $salt = $existinginfo["salt"];
    $hash = $existinginfo["hash"];;

    $loginhash = crypt($password, $salt);
    if ($hash != $loginhash){
        echo "6: Incorrect password"; //error incorrect
        exit();
    }

    echo "0\t" . $existinginfo["amountofwins"] . "\t" . $existinginfo["amountoflosses"];
        

?>