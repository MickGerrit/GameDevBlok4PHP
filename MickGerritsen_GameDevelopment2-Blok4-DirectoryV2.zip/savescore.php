<?php
    define("DB_SERVER", "localhost");
    define("DB_USER", "mickgerritsen");
    define("DB_PASSWORD", "bohghooP2l");
    define("DB_DATABASE", "mickgerritsen");

    $con = mysqli_connect(DB_SERVER , DB_USER, DB_PASSWORD, DB_DATABASE);
    
    //check connection
    if (mysqli_connect_errno()){
        echo "1: Connection failed"; //failed
        exit();
    }

    $score = $_POST["score"];
    $winner = $_POST["winner"];
    $loser = $_POST["loser"];

    $namecheckquerywinner = "SELECT username FROM users WHERE username='" . $winner . "';";
    $namecheckqueryloser = "SELECT username FROM users WHERE username='" . $loser . "';";

    //double chec k for the user
    $namecheckwinner = mysqli_query($con, $namecheckquerywinner) or die("2: Name check query failed"); //namecheck query failed
    $namecheckloser = mysqli_query($con, $namecheckqueryloser) or die("2: Name check query failed"); //namecheck query failed

    if (mysqli_num_rows($namecheckwinner) != 1 && mysqli_num_rows($namecheckloser) != 1){
        echo "5: Either no user with name or more than one"; //wrong matching username
        exit();
    }

    $timestamp = date("Y-m-d H:i:s");
    $updatequery = "INSERT INTO games (score, winner, loser) VALUES ('". $score ."', '". $winner ."', '". $loser . "');";

    mysqli_query($con, $updatequery) or die(mysqli_error($con));// update query failed
    echo "0";

?>