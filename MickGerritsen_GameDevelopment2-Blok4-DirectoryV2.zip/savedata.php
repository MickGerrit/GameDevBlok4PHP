<?php
    define("DB_SERVER", "localhost");
    define("DB_USER", "mickgerritsen");
    define("DB_PASSWORD", "bohghooP2l");
    define("DB_DATABASE", "mickgerritsen");

    $con = mysqli_connect(DB_SERVER , DB_USER, DB_PASSWORD, DB_DATABASE);
    
    //check connection
    if (mysqli_connect_errno()){
        echo "1: Connection failed"; //failed
        exit();
    }

    $username = $_POST["username"];
    $won = $_POST["amountofwins"];
    $lost = $_POST["amountoflosses"];

    $namecheckquery = "SELECT username FROM users WHERE username='" . $username . "';";

    //double chec k for the user
    $namecheck = mysqli_query($con, $namecheckquery) or die("2: Name check query failed"); //namecheck query failed

    if (mysqli_num_rows($namecheck) != 1){
        echo "5: Either no user with name or more than one"; //wrong matching username
        exit();
    }
    
    $updatequery = "UPDATE users SET amountofwins = " . $won . " WHERE username = '" . $username . "';";
    mysqli_query($con, $updatequery) or die("7: Save query failed");// update query failed
    $updatequery = "UPDATE users SET amountoflosses = " . $lost . " WHERE username = '" . $username . "';";
    mysqli_query($con, $updatequery) or die("7: Save query failed");// update query failed
    echo "0";

?>